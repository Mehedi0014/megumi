<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'drazeeeb_mehedimegumi' );

/** MySQL database username */
define( 'DB_USER', 'drazeeeb_mehedi' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Admin=Mehedi0013' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '!T<]O{uag&>3eY<!i[I?sD4x-4]D#;MlP*sL kx;0]2emPyX8ncNTq!m:SPV=c3%' );
define( 'SECURE_AUTH_KEY',  'iL;}FYdvnAP$4KNVR}]?a!Z7f;;2+^a=s:O!$4[^?Ov_z/I*r?Rj`<ZsxycAq=v8' );
define( 'LOGGED_IN_KEY',    'i4sjbTa=vs0_da()ym1DVNV0qAMq4_ZO=3TL5+jq$_Ns5M>jYSptzWFBh>MG/Bt~' );
define( 'NONCE_KEY',        '>S0JDXCnQc?B#v~m[Pup5VH@<7?/k.s*ZVygosOVov[5 =.OuaPYZtP!ky%x=mCI' );
define( 'AUTH_SALT',        '&QDt8Y;,B::uo_Ds4qShG,`+~kL|h?:f(?=2-ny8Fl3x_Zc^,m1l<{@mqG3/vc#Z' );
define( 'SECURE_AUTH_SALT', '0H>&n[ijNyh:p43Y5q,v(nD]v*|<7$np#ZfJI`RaW~X0+~5s9-L+/){GY+6oOKc:' );
define( 'LOGGED_IN_SALT',   '3qfT:j[No~kkvdPZYn3Ez_,sE6WK?k]RX@2*D{brrddqw1da{vr[d@.48H5?zQ/)' );
define( 'NONCE_SALT',       '#DJa[1zq7(iy0!l!hcfmXBN`GmRi>F?YDub|)Y7!1M-eq1`fx)]p,7d(W0o82#VC' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'mmhs_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
